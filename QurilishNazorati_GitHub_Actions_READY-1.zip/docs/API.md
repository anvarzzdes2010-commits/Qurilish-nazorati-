# API qisqacha

POST /api/auth/login
GET /api/projects
POST /api/projects (rahbar)
GET /api/projects/{id}/estimate
GET /api/reports?project_id=1
POST /api/reports (prarab)
POST /api/reports/{id}/decision (pto; decision=approved|rejected)
GET /api/notifications
GET /api/analytics?project_id=1
POST /api/users (rahbar)

Authorization:
Authorization: Bearer TOKEN
