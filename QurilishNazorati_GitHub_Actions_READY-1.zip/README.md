# Qurilish Nazorati — Android + PHP/MySQL

Tarkib:
- Android Kotlin app
- PHP REST API backend
- MySQL schema
- Rahbar / Prarab / PTO rollari
- Login session
- Obyektlar
- Smeta pozitsiyalari
- Prarab hisobotlari + foto
- PTO tasdiqlash/rad etish
- Rahbar/PTO notification feed
- Analitika
- Excel/CSV import endpoint
- PDF upload endpoint (PDF parsing uchun serverda pdftotext yoki maxsus parser ulash mumkin)

## 1. Backend
`backend/config.php` ni sozlang:
- DB_HOST
- DB_NAME
- DB_USER
- DB_PASS
- BASE_URL

MySQL'da `backend/database/schema.sql` ni import qiling.

Backend papkasini PHP 8.1+ hostingga joylang.
Document root sifatida `backend/public` ishlatiladi.

Birinchi Rahbar:
POST /api/auth/login orqali emas, `backend/database/seed_admin.php` yordamida yaratiladi.
Seed faylini ishlatgandan keyin o'chiring.

## 2. Android
Android Studio'da shu root loyihani oching.
`app/build.gradle.kts` ichidagi API_BASE_URL ni hosting manziliga almashtiring.

Debug APK:
./gradlew assembleDebug

Release APK:
./gradlew assembleRelease

Release uchun Android Studio Signing Config bilan o'zingizning keystore'ingizni qo'shing.

## 3. Muhim
Bu loyiha real backendga ulanish uchun yozilgan. APK ichiga maxfiy DB parolini joylamang.
Production uchun HTTPS majburiy.
