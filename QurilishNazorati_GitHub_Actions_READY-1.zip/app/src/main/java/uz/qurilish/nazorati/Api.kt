package uz.qurilish.nazorati

import retrofit2.http.*
import okhttp3.MultipartBody
import okhttp3.RequestBody

data class LoginRequest(val username:String, val password:String)
data class LoginResponse(val ok:Boolean, val token:String?, val user:User?, val message:String?)
data class User(val id:Int, val full_name:String, val username:String, val role:String)
data class ApiResponse<T>(val ok:Boolean, val data:T?, val message:String?)
data class Project(val id:Int, val name:String, val estimate_file:String?, val created_at:String?)
data class EstimateItem(val id:Int, val code:String?, val name:String, val unit:String?, val planned_qty:Double, val completed_qty:Double, val status:String)
data class Report(val id:Int, val project_id:Int, val estimate_item_id:Int?, val type:String, val description:String?, val qty:Double, val status:String, val photo_url:String?, val created_at:String)

interface Api {
    @POST("auth/login") suspend fun login(@Body body:LoginRequest): LoginResponse
    @GET("projects") suspend fun projects(@Header("Authorization") token:String): ApiResponse<List<Project>>
    @POST("projects") suspend fun createProject(@Header("Authorization") token:String, @Body body:Map<String,String>): ApiResponse<Project>
    @GET("projects/{id}/estimate") suspend fun estimate(@Header("Authorization") token:String, @Path("id") id:Int): ApiResponse<List<EstimateItem>>
    @GET("reports") suspend fun reports(@Header("Authorization") token:String, @Query("project_id") projectId:Int): ApiResponse<List<Report>>
    @POST("reports") suspend fun createReport(@Header("Authorization") token:String, @Body body:Map<String,Any>): ApiResponse<Report>
    @POST("reports/{id}/decision") suspend fun decision(@Header("Authorization") token:String, @Path("id") id:Int, @Body body:Map<String,String>): ApiResponse<Report>
    @GET("notifications") suspend fun notifications(@Header("Authorization") token:String): ApiResponse<List<Map<String,Any>>>
    @GET("analytics") suspend fun analytics(@Header("Authorization") token:String, @Query("project_id") id:Int): ApiResponse<Map<String,Any>>
    @Multipart
    @POST("reports/photo") suspend fun uploadPhoto(@Header("Authorization") token:String, @Part photo:MultipartBody.Part, @Part("report_id") reportId:RequestBody): ApiResponse<Map<String,String>>
}
