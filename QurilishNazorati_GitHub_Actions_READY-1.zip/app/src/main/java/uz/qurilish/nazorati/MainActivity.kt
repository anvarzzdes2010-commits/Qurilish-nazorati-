package uz.qurilish.nazorati

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.coroutines.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity: AppCompatActivity() {
    private val baseUrl = "https://YOUR-DOMAIN.example/api/"
    private lateinit var api: Api
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var content: LinearLayout
    private lateinit var subtitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        subtitle = findViewById(R.id.subtitle)
        content = findViewById(R.id.content)
        prefs = EncryptedSharedPreferences.create(
            "session",
            MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
            this,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        api = Retrofit.Builder().baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create()).build().create(Api::class.java)
        if (prefs.getString("token", null) == null) showLogin() else showDashboard()
    }

    private fun showLogin() {
        content.removeAllViews()
        subtitle.text = "Tizimga kirish"
        val user = EditText(this); user.hint = "Login"
        val pass = EditText(this); pass.hint = "Parol"; pass.inputType = 0x81
        val btn = Button(this); btn.text = "Kirish"
        content.addView(user); content.addView(pass); content.addView(btn)
        btn.setOnClickListener {
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    val r = withContext(Dispatchers.IO) { api.login(LoginRequest(user.text.toString(), pass.text.toString())) }
                    if (r.ok && r.token != null) {
                        prefs.edit().putString("token", r.token).putString("role", r.user?.role).apply()
                        showDashboard()
                    } else Toast.makeText(this@MainActivity, r.message ?: "Login xatosi", Toast.LENGTH_LONG).show()
                } catch(e:Exception) { Toast.makeText(this@MainActivity, e.message ?: "Server xatosi", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun showDashboard() {
        val token = "Bearer " + prefs.getString("token","")
        val role = prefs.getString("role","")
        content.removeAllViews()
        subtitle.text = "Kabinet: $role"
        val logout = Button(this); logout.text = "Chiqish"
        content.addView(logout)
        logout.setOnClickListener { prefs.edit().clear().apply(); showLogin() }

        val projectsBtn = Button(this); projectsBtn.text = "Obyektlar"
        content.addView(projectsBtn)
        projectsBtn.setOnClickListener { loadProjects(token) }

        if (role == "rahbar") {
            val add = Button(this); add.text = "＋ Yangi obyekt qo‘shish"
            content.addView(add)
            add.setOnClickListener { createProjectDialog(token) }
        }
        if (role == "pto" || role == "rahbar") {
            val n = Button(this); n.text = "🔔 Bildirishnomalar"
            content.addView(n)
            n.setOnClickListener { loadNotifications(token) }
        }
    }

    private fun loadProjects(token:String) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val r = withContext(Dispatchers.IO) { api.projects(token) }
                content.removeAllViews()
                r.data.orEmpty().forEach { p ->
                    val b=Button(this@MainActivity); b.text="🏗 ${p.name}"
                    content.addView(b)
                    b.setOnClickListener { loadEstimate(token,p) }
                }
            } catch(e:Exception) { toast(e.message ?: "Xato") }
        }
    }

    private fun loadEstimate(token:String,p:Project) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val r=withContext(Dispatchers.IO){api.estimate(token,p.id)}
                content.removeAllViews()
                r.data.orEmpty().forEach { i ->
                    val t=TextView(this@MainActivity)
                    t.text="${i.code ?: ""}  ${i.name}\n${i.completed_qty}/${i.planned_qty} ${i.unit ?: ""}  [${i.status}]"
                    t.setPadding(10,18,10,18)
                    content.addView(t)
                }
            } catch(e:Exception){toast(e.message ?: "Xato")}
        }
    }

    private fun createProjectDialog(token:String) {
        val input=EditText(this); input.hint="Obyekt nomi"
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Yangi obyekt")
            .setView(input).setPositiveButton("Saqlash"){_,_->
                CoroutineScope(Dispatchers.Main).launch {
                    try {
                        withContext(Dispatchers.IO){api.createProject(token,mapOf("name" to input.text.toString()))}
                        loadProjects(token)
                    }catch(e:Exception){toast(e.message ?: "Xato")}
                }
            }.setNegativeButton("Bekor",null).show()
    }

    private fun loadNotifications(token:String) {
        CoroutineScope(Dispatchers.Main).launch {
            val r=withContext(Dispatchers.IO){api.notifications(token)}
            content.removeAllViews()
            r.data.orEmpty().forEach {
                val t=TextView(this@MainActivity); t.text=it.toString(); t.setPadding(10,15,10,15); content.addView(t)
            }
        }
    }

    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
