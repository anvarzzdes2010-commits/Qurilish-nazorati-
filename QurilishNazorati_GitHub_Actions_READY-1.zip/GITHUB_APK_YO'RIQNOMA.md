# Telefon orqali APK olish

1. GitHub.com saytiga kiring va akkauntga kiring.
2. New repository yarating. Public tanlash eng oson bepul variant.
3. ZIPni Extract qiling.
4. Loyihadagi barcha fayllarni repositoryga yuklang. `.github/workflows/build-apk.yml` ham yuklanganiga ishonch hosil qiling.
5. Repository → Actions → "Build Android APK" ni tanlang.
6. "Run workflow" ni bosing.
7. Build tugagach workflow run ichiga kiring.
8. Pastdagi Artifacts bo‘limidan `QurilishNazorati-debug-apk` ni yuklab oling.
9. ZIP artifactni ochib `app-debug.apk` ni telefonga o‘rnating.

MUHIM:
- Bu workflow APKni kompilyatsiya qiladi.
- Hozirgi source hali backend domeniga `YOUR-DOMAIN.example` bilan qaraydi.
- Haqiqiy login, obyektlar, sinxronizatsiya va onlayn funksiyalar ishlashi uchun PHP/MySQL backendni hostingga joylash va Androiddagi API manzilini almashtirish kerak.
- Debug APK ommaviy Play Store relizi emas. Release uchun signing/keystore va production backend/HTTPS kerak.
