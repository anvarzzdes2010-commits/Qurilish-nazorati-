<?php
return [
  'db_host' => getenv('DB_HOST') ?: '127.0.0.1',
  'db_name' => getenv('DB_NAME') ?: 'qurilish_nazorati',
  'db_user' => getenv('DB_USER') ?: 'root',
  'db_pass' => getenv('DB_PASS') ?: '',
  'base_url' => getenv('BASE_URL') ?: 'https://YOUR-DOMAIN.example/api',
  'upload_dir' => __DIR__ . '/storage/uploads'
];
