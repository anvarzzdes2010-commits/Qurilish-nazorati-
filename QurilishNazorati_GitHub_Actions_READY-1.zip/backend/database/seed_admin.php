<?php
// Run once from CLI, then DELETE this file.
$config=require __DIR__.'/../config.php';
$pdo=new PDO(
 "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
 $config['db_user'],$config['db_pass'],
 [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]
);
$username=$argv[1] ?? 'rahbar';
$password=$argv[2] ?? 'ChangeMe_123!';
$name=$argv[3] ?? 'Bosh rahbar';
$st=$pdo->prepare("INSERT INTO users(full_name,username,password_hash,role) VALUES(?,?,?,'rahbar')");
$st->execute([$name,$username,password_hash($password,PASSWORD_DEFAULT)]);
echo "Created: $username\n";
