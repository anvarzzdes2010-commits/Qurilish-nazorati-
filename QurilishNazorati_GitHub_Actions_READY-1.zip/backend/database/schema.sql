CREATE DATABASE IF NOT EXISTS qurilish_nazorati CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE qurilish_nazorati;

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(150) NOT NULL,
 username VARCHAR(80) UNIQUE NOT NULL,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('rahbar','prarab','pto') NOT NULL,
 active TINYINT(1) DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sessions (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 token_hash CHAR(64) UNIQUE NOT NULL,
 expires_at DATETIME NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE projects (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(255) NOT NULL,
 estimate_file VARCHAR(500),
 created_by INT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(created_by) REFERENCES users(id)
);

CREATE TABLE estimate_items (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 project_id INT NOT NULL,
 code VARCHAR(100),
 name VARCHAR(500) NOT NULL,
 unit VARCHAR(50),
 planned_qty DECIMAL(18,3) DEFAULT 0,
 completed_qty DECIMAL(18,3) DEFAULT 0,
 status ENUM('planned','pending','approved') DEFAULT 'planned',
 UNIQUE(project_id,code,name),
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE TABLE reports (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 project_id INT NOT NULL,
 estimate_item_id BIGINT NULL,
 author_id INT NOT NULL,
 type ENUM('material','work') NOT NULL,
 description TEXT,
 qty DECIMAL(18,3) NOT NULL DEFAULT 0,
 status ENUM('pending','approved','rejected') DEFAULT 'pending',
 photo_url VARCHAR(500),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 decided_by INT NULL,
 decided_at DATETIME NULL,
 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
 FOREIGN KEY(estimate_item_id) REFERENCES estimate_items(id) ON DELETE SET NULL,
 FOREIGN KEY(author_id) REFERENCES users(id),
 FOREIGN KEY(decided_by) REFERENCES users(id)
);

CREATE TABLE notifications (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 title VARCHAR(255) NOT NULL,
 body TEXT NOT NULL,
 report_id BIGINT NULL,
 is_read TINYINT(1) DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(report_id) REFERENCES reports(id) ON DELETE SET NULL
);
