<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Authorization, Content-Type');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if($_SERVER['REQUEST_METHOD']==='OPTIONS'){exit;}

$config=require __DIR__.'/../config.php';
$pdo=new PDO(
 "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
 $config['db_user'],$config['db_pass'],
 [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
);

function out($x,$code=200){http_response_code($code);echo json_encode($x,JSON_UNESCAPED_UNICODE);exit;}
function body(){return json_decode(file_get_contents('php://input'),true) ?: [];}
function auth($pdo){
 $h=$_SERVER['HTTP_AUTHORIZATION']??'';
 if(!preg_match('/Bearer\s+(.+)/i',$h,$m)) out(['ok'=>false,'message'=>'Unauthorized'],401);
 $hash=hash('sha256',$m[1]);
 $q=$pdo->prepare("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>NOW() AND u.active=1");
 $q->execute([$hash]); $u=$q->fetch(); if(!$u) out(['ok'=>false,'message'=>'Session expired'],401); return $u;
}
function role($u,$roles){if(!in_array($u['role'],$roles,true)) out(['ok'=>false,'message'=>'Ruxsat yo‘q'],403);}

$path=trim(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH),'/');
$parts=explode('/',$path);
$api=array_search('api',$parts,true);
$route=$api!==false ? implode('/',array_slice($parts,$api+1)) : '';
$method=$_SERVER['REQUEST_METHOD'];

if($route==='auth/login' && $method==='POST'){
 $b=body(); $q=$pdo->prepare("SELECT * FROM users WHERE username=? AND active=1"); $q->execute([$b['username']??'']); $u=$q->fetch();
 if(!$u || !password_verify($b['password']??'',$u['password_hash'])) out(['ok'=>false,'message'=>'Login yoki parol noto‘g‘ri'],401);
 $token=bin2hex(random_bytes(32));
 $st=$pdo->prepare("INSERT INTO sessions(user_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 30 DAY))");
 $st->execute([$u['id'],hash('sha256',$token)]);
 unset($u['password_hash']);
 out(['ok'=>true,'token'=>$token,'user'=>['id'=>$u['id'],'full_name'=>$u['full_name'],'username'=>$u['username'],'role'=>$u['role']]]);
}

$u=auth($pdo);

if($route==='projects' && $method==='GET'){
 $q=$pdo->query("SELECT id,name,estimate_file,created_at FROM projects ORDER BY id DESC");
 out(['ok'=>true,'data'=>$q->fetchAll()]);
}
if($route==='projects' && $method==='POST'){
 role($u,['rahbar']); $b=body();
 $st=$pdo->prepare("INSERT INTO projects(name,created_by) VALUES(?,?)");
 $st->execute([$b['name']??'',$u['id']]);
 out(['ok'=>true,'data'=>['id'=>(int)$pdo->lastInsertId(),'name'=>$b['name']??'']]);
}
if(preg_match('#^projects/(\d+)/estimate$#',$route,$m) && $method==='GET'){
 $st=$pdo->prepare("SELECT id,code,name,unit,planned_qty,completed_qty,status FROM estimate_items WHERE project_id=? ORDER BY id");
 $st->execute([(int)$m[1]]); out(['ok'=>true,'data'=>$st->fetchAll()]);
}
if($route==='reports' && $method==='GET'){
 $pid=(int)($_GET['project_id']??0);
 $st=$pdo->prepare("SELECT * FROM reports WHERE project_id=? ORDER BY id DESC");$st->execute([$pid]);
 out(['ok'=>true,'data'=>$st->fetchAll()]);
}
if($route==='reports' && $method==='POST'){
 role($u,['prarab']);
 $b=body(); $pid=(int)$b['project_id']; $item=$b['estimate_item_id']??null;
 $st=$pdo->prepare("INSERT INTO reports(project_id,estimate_item_id,author_id,type,description,qty) VALUES(?,?,?,?,?,?)");
 $st->execute([$pid,$item,$u['id'],$b['type']??'work',$b['description']??'',(float)($b['qty']??0)]);
 $rid=(int)$pdo->lastInsertId();
 $q=$pdo->query("SELECT id FROM users WHERE role IN ('rahbar','pto') AND active=1");
 $ins=$pdo->prepare("INSERT INTO notifications(user_id,title,body,report_id) VALUES(?,?,?,?)");
 foreach($q->fetchAll() as $r) $ins->execute([$r['id'],'Yangi hisobot',"Prarab yangi hisobot yubordi #$rid",$rid]);
 out(['ok'=>true,'data'=>['id'=>$rid]]);
}
if(preg_match('#^reports/(\d+)/decision$#',$route,$m) && $method==='POST'){
 role($u,['pto']); $b=body(); $decision=$b['decision']??'';
 if(!in_array($decision,['approved','rejected'],true)) out(['ok'=>false,'message'=>'Noto‘g‘ri qaror'],422);
 $pdo->beginTransaction();
 $st=$pdo->prepare("UPDATE reports SET status=?,decided_by=?,decided_at=NOW() WHERE id=? AND status='pending'");
 $st->execute([$decision,$u['id'],(int)$m[1]]);
 $st=$pdo->prepare("SELECT * FROM reports WHERE id=?");$st->execute([(int)$m[1]]);$r=$st->fetch();
 if($decision==='approved' && $r && $r['estimate_item_id']){
   $st=$pdo->prepare("UPDATE estimate_items SET completed_qty=completed_qty+?,status='approved' WHERE id=?");
   $st->execute([$r['qty'],$r['estimate_item_id']]);
 }
 $q=$pdo->query("SELECT id FROM users WHERE role='rahbar' AND active=1");
 $ins=$pdo->prepare("INSERT INTO notifications(user_id,title,body,report_id) VALUES(?,?,?,?)");
 foreach($q->fetchAll() as $x) $ins->execute([$x['id'],'PTO qarori',"Hisobot #{$m[1]}: $decision",(int)$m[1]]);
 $pdo->commit();
 out(['ok'=>true,'data'=>$r]);
}
if($route==='notifications' && $method==='GET'){
 $st=$pdo->prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 100");$st->execute([$u['id']]);
 out(['ok'=>true,'data'=>$st->fetchAll()]);
}
if($route==='analytics' && $method==='GET'){
 $pid=(int)($_GET['project_id']??0);
 $st=$pdo->prepare("SELECT COUNT(*) items,SUM(planned_qty) planned,SUM(completed_qty) completed FROM estimate_items WHERE project_id=?");$st->execute([$pid]);
 out(['ok'=>true,'data'=>$st->fetch()]);
}
if($route==='users' && $method==='POST'){
 role($u,['rahbar']); $b=body();
 $st=$pdo->prepare("INSERT INTO users(full_name,username,password_hash,role) VALUES(?,?,?,?)");
 $st->execute([$b['full_name'],$b['username'],password_hash($b['password'],PASSWORD_DEFAULT),$b['role']]);
 out(['ok'=>true,'message'=>'Xodim yaratildi']);
}
out(['ok'=>false,'message'=>'Endpoint topilmadi'],404);
